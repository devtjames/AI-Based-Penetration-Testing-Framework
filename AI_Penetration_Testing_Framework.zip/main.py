# main.py
"""
AI-Based Penetration Testing Framework — Streamlit single-file app
Landing page + Scan + Reports + Settings + About
CSV export only (no PDF)
Author: Taye James Adeboye
Supervisor: Dr. Lawal T.D.
Matric: CS/HND/F22/3399
"""
import streamlit as st
import subprocess
import shutil
import os
import socket
import time
import csv
import io
from urllib.parse import urlparse
from datetime import datetime
import requests
import pandas as pd
import warnings

# ----------------------------
# Config / Project Info
# ----------------------------
warnings.filterwarnings("ignore", message="Unverified HTTPS request")
st.set_page_config(page_title="AI Pentest Framework", layout="wide")
PROJECT_TITLE = "Development of an AI-Based Penetration Testing Framework"
SUPERVISOR = "Dr. Lawal T.D."
STUDENT = "Taye James Adeboye"
MATRIC = "CS/HND/F22/3399"

COMMON_NMAP_PATHS = [
    r"C:\Program Files (x86)\Nmap\nmap.exe",
    r"C:\Program Files\Nmap\nmap.exe",
    r"C:\Program Files (x86)\Nmap",
    r"C:\Program Files\Nmap",
    "/usr/bin/nmap",
    "/usr/local/bin/nmap",
]

# ----------------------------
# Helpers: safe rerun
# ----------------------------
def _safe_rerun():
    """Try to rerun the Streamlit script; do not crash if api not available."""
    try:
        st.experimental_rerun()
    except Exception:
        # some Streamlit installs don't expose experimental_rerun; ignore
        pass

# ----------------------------
# Nmap helpers
# ----------------------------
def find_nmap_executable():
    exe = shutil.which("nmap")
    if exe:
        return exe
    for p in COMMON_NMAP_PATHS:
        if os.path.isfile(p):
            return p
        if os.path.isdir(p):
            candidate = os.path.join(p, "nmap.exe")
            if os.path.isfile(candidate):
                return candidate
    return None

def ensure_nmap_in_path(manual_path=None):
    if manual_path:
        if os.path.isfile(manual_path):
            folder = os.path.dirname(manual_path)
            os.environ["PATH"] = folder + os.pathsep + os.environ.get("PATH", "")
            return manual_path
        else:
            return None
    found = find_nmap_executable()
    if found:
        folder = os.path.dirname(found)
        os.environ["PATH"] = folder + os.pathsep + os.environ.get("PATH", "")
        return found
    return None

def nmap_available(manual_path=None):
    p = ensure_nmap_in_path(manual_path)
    if not p:
        return False, None
    try:
        subprocess.run(["nmap","--version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        return True, p
    except Exception:
        return False, None

def run_nmap_scan_binary(target, args=None, timeout=120):
    base = ["nmap"]
    if args:
        cmd = base + args + [target]
    else:
        cmd = base + ["-sV", "-Pn", target]
    try:
        out = subprocess.check_output(cmd, stderr=subprocess.STDOUT, text=True, timeout=timeout)
        return True, out
    except subprocess.CalledProcessError as e:
        return False, e.output
    except FileNotFoundError:
        return False, "nmap not found"
    except Exception as e:
        return False, str(e)

# ----------------------------
# Target normalization & TCP probe
# ----------------------------
def normalize_target(input_str: str):
    if not input_str:
        return None
    t = input_str.strip()
    if t.startswith("http://") or t.startswith("https://"):
        parsed = urlparse(t)
        hostname = parsed.hostname
        scheme = parsed.scheme
        base = f"{scheme}://{hostname}"
        return {"original": input_str, "hostname": hostname, "base": base}
    if "/" in t:
        parsed = urlparse("http://" + t)
        hostname = parsed.hostname
        return {"original": input_str, "hostname": hostname, "base": f"http://{hostname}"}
    return {"original": input_str, "hostname": t, "base": f"http://{t}"}

def tcp_probe(host, port, timeout=1.2):
    try:
        s = socket.socket()
        s.settimeout(timeout)
        s.connect((host, port))
        s.close()
        return True
    except Exception:
        return False

def tcp_probe_ports(host, ports, progress=None):
    open_ports = []
    total = len(ports)
    for i,p in enumerate(ports):
        try:
            if tcp_probe(host,p):
                open_ports.append(p)
        except Exception:
            pass
        if progress:
            # progress expects a percent (0-100)
            progress(int((i+1)/total*100))
    return open_ports

# ----------------------------
# HTTP/web checks & quick vuln tests
# ----------------------------
def http_get(url, timeout=5):
    try:
        r = requests.get(url, timeout=timeout, allow_redirects=True, verify=False,
                         headers={"User-Agent":"AI-Pentest/1.0"})
        return r
    except Exception:
        return None

def basic_web_checks(base_url):
    findings = []
    base_resp = http_get(base_url)
    if base_resp:
        findings.append({"endpoint": base_url, "status": base_resp.status_code,
                         "server": base_resp.headers.get("Server"), "snippet": (base_resp.text or "")[:400]})
    else:
        if base_url.startswith("https://"):
            base2 = "http://" + base_url.split("://",1)[1]
            base_resp = http_get(base2)
            if base_resp:
                base_url = base2
                findings.append({"endpoint": base_url, "status": base_resp.status_code,
                                 "server": base_resp.headers.get("Server"), "snippet": (base_resp.text or "")[:400]})
    endpoints = ["/robots.txt","/.env","/phpinfo.php","/.git/config","/admin","/login"]
    for ep in endpoints:
        url = base_url.rstrip("/") + ep
        r = http_get(url)
        if r and r.status_code == 200:
            findings.append({"endpoint": url, "status": r.status_code,
                             "server": r.headers.get("Server"), "snippet": (r.text or "")[:400]})
    return findings

def run_basic_web_vuln_tests(base_url):
    vulns = []
    session = requests.Session()
    session.headers.update({"User-Agent":"AI-Pentest/1.0"})
    tests = {"XSS":"<script>alert(1)</script>", "SQLi":"' OR '1'='1"}
    for name,payload in tests.items():
        url = base_url.rstrip("/") + "/?q=" + requests.utils.requote_uri(payload)
        try:
            r = session.get(url, timeout=6, verify=False)
            body = (r.text or "").lower()
            if name == "XSS" and payload.lower() in body:
                vulns.append({"title":"Reflected XSS", "evidence":f"Payload reflected - {url}",
                              "severity":"Medium", "recommendation":"Sanitise & encode input; use CSP; escape output."})
            if name == "SQLi" and any(k in body for k in ["sql syntax","mysql","syntax error","sql error","odbc","postgresql"]):
                vulns.append({"title":"Possible SQL Injection", "evidence":f"SQL error-like content - {url}",
                              "severity":"High", "recommendation":"Use prepared statements & input validation."})
        except Exception:
            continue
    return vulns

# ----------------------------
# AI heuristic
# ----------------------------
def ai_assess(vuln_records):
    if not vuln_records:
        return {"level":"Secure","score":0,"recommendation":"No issues found. Regular scanning recommended."}
    score = 0
    for v in vuln_records:
        sev = v.get("severity","Low").lower()
        if sev.startswith("crit") or sev=="critical":
            score += 90
        elif sev.startswith("high") or sev=="high":
            score += 70
        elif sev.startswith("medium") or sev=="medium":
            score += 40
        else:
            score += 10
    avg = score / len(vuln_records)
    if avg >= 70:
        level="Critical"; rec="Immediate action: isolate services, apply patches, incident response."
    elif avg >= 50:
        level="High"; rec="Urgent: schedule patching & review access controls."
    elif avg >= 30:
        level="Medium"; rec="Remediate misconfigurations and harden services."
    else:
        level="Low"; rec="Low risk: monitor and schedule routine maintenance."
    return {"level":level,"score":int(avg),"recommendation":rec}

# ----------------------------
# CSV generator (export only)
# ----------------------------
def generate_csv_buffer(scan_meta, vuln_list):
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["Scan ID","Target","Engine","Started at","Duration (s)"])
    writer.writerow([scan_meta.get("scan_id"), scan_meta.get("target"), scan_meta.get("engine"),
                     scan_meta.get("started_at"), scan_meta.get("duration")])
    writer.writerow([])
    writer.writerow(["Endpoint","Title","Severity","Recommendation","Evidence"])
    for v in vuln_list:
        writer.writerow([v.get("endpoint") or "", v.get("title"), v.get("severity"),
                         v.get("recommendation",""), v.get("evidence","")])
    buf.seek(0)
    return buf

# ----------------------------
# Top compact header (non-landing)
# ----------------------------
def top_header_compact():
    cols = st.columns([4,1])
    cols[0].markdown(f"**{PROJECT_TITLE}**  \n*Supervisor:* {SUPERVISOR}  \n*Student:* {STUDENT} — {MATRIC}")
    return

# ----------------------------
# Landing page (hero)
# ----------------------------
def landing_page():
    st.markdown(
        """
        <style>
        .landing-container {
            text-align: center;
            padding-top: 120px;
            color: white;
        }
        .landing-title {
            font-size: 42px;
            font-weight: 700;
            color: #f8fafc;
        }
        .landing-topic {
            font-size: 20px;
            margin-top: 20px;
            color: #cbd5e1;
        }
        .landing-details {
            font-size: 18px;
            margin-top: 10px;
            color: #94a3b8;
        }
        .school-name {
            font-size: 18px;
            margin-top: 20px;
            color: #94a3b8;
            font-weight: 500;
        }
        </style>

        <div class="landing-container">
            <div class="landing-title">🧠 AI-Based Penetration Testing Framework</div>
            <div class="landing-topic"><strong>Topic:</strong> Development of an AI-Based Penetration Testing Framework</div>
            <div class="landing-details">Student Matric No: <strong>CS/HND/F22/3399</strong></div>
            <div class="landing-details">Supervisor: <strong>Dr. Lawal T.D.</strong></div>
            <div class="school-name">School: <strong>FEDERAL POLYTECHNIC OFFA</strong></div>
        </div>
        """,
        unsafe_allow_html=True
    )

    st.write("")  # spacing
    st.write("")
    st.write("")
    col1, col2, col3 = st.columns([2, 1, 2])
    with col2:
        if st.button("🚀 Go to Dashboard", use_container_width=True):
            st.session_state["page"] = "Scan"
            _safe_rerun()


# ----------------------------
# Scan UI
# ----------------------------
def scan_ui():
    top_header_compact()
    st.header("Scan Target")
    st.info("Only scan systems you own or have explicit permission to test.", icon="⚠️")

    with st.form("scan_form", clear_on_submit=False):
        target_input = st.text_input("Target (domain, host, or URL)", placeholder="example.com or https://example.com", key="target_input")
        engine_choice = st.selectbox("Engine preference", options=["Auto (use nmap if available)", "Force TCP fallback"], index=0, key="engine_choice")
        submitted = st.form_submit_button("Start Scan", use_container_width=True, key="start_scan_btn")
    if not submitted:
        return

    norm = normalize_target(target_input)
    if not norm:
        st.error("Couldn't parse target; provide a hostname or full URL like https://example.com", icon="🚫")
        return
    hostname = norm["hostname"]
    base_url = norm["base"]
    # resolve
    try:
        ip = socket.gethostbyname(hostname)
    except Exception as e:
        st.error(f"DNS resolution failed: {e}")
        st.code(f"nslookup {hostname}\nping {hostname}")
        return

    manual = st.session_state.get("manual_nmap_path","")
    if engine_choice == "Force TCP fallback":
        nmap_ok = False
    else:
        nmap_ok, _ = nmap_available(manual_path=manual)
    engine_used = "nmap" if nmap_ok else "tcp_fallback"

    st.write(f"Starting scan for `{hostname}` ({ip}) using `{engine_used}` — {datetime.utcnow().isoformat()}Z")
    start = time.time()

    top_ports = [21,22,23,25,53,80,110,139,143,443,445,3389,3306,8080]
    vuln_records = []

    if nmap_ok:
        ok, raw = run_nmap_scan_binary(ip, args=["-sV","-Pn","-T4"])
        raw_nmap_output = raw if ok else ""
        st.subheader("Nmap output (raw)")
        st.code(raw_nmap_output or "(no output)")
        for line in (raw_nmap_output or "").splitlines():
            if "/tcp" in line and "open" in line:
                parts = line.split()
                try:
                    port_part = parts[0]
                    port = int(port_part.split("/")[0])
                except Exception:
                    continue
                vuln_records.append({"endpoint": f"{hostname}:{port}", "title": f"Open port {port}",
                                     "severity": "Low" if port not in (3306,3389,445) else "High",
                                     "recommendation": "Restrict to internal access / firewall", "evidence": line})
        if not any("/tcp" in l and "open" in l for l in (raw_nmap_output or "").splitlines()):
            st.info("Nmap returned no open ports — running TCP fallback probe.")
            progress = st.progress(0, key="probe_progress_1")
            open_ports = tcp_probe_ports(ip, top_ports, progress=lambda v: progress.progress(v))
            progress.empty()
            for p in open_ports:
                vuln_records.append({"endpoint": f"{hostname}:{p}", "title": f"Open port {p}",
                                     "severity": "Low" if p not in (3306,3389,445) else "High",
                                     "recommendation": "Restrict via firewall", "evidence": f"tcp_probe:{p}"})
    else:
        progress = st.progress(0, key="probe_progress_2")
        open_ports = tcp_probe_ports(ip, top_ports, progress=lambda v: progress.progress(v))
        progress.empty()
        if open_ports:
            st.success(f"Open ports found: {open_ports}")
            for p in open_ports:
                vuln_records.append({"endpoint": f"{hostname}:{p}", "title": f"Open port {p}",
                                     "severity": "Low" if p not in (3306,3389,445) else "High",
                                     "recommendation": "Restrict via firewall", "evidence": f"tcp_probe:{p}"})
        else:
            st.info("No open ports found with TCP probe.")

    # Web checks if applicable
    do_web = any(int(r["endpoint"].split(":")[-1]) in (80,443,8080) for r in vuln_records) or base_url.startswith("http")
    web_findings = []
    if do_web:
        st.subheader("Web checks & quick tests")
        web_findings = basic_web_checks(base_url)
        if web_findings:
            st.write("HTTP endpoints discovered:")
            st.table(pd.DataFrame(web_findings))
        for wf in web_findings:
            ep = wf.get("endpoint","")
            if "/.env" in ep or "/phpinfo.php" in ep or "/.git/config" in ep:
                vuln_records.append({"endpoint": ep, "title":"Exposed sensitive file", "severity":"High",
                                     "recommendation":"Remove from webroot / rotate secrets", "evidence": wf.get("snippet","")})
            elif "robots" in ep:
                vuln_records.append({"endpoint": ep, "title":"robots.txt disclosure", "severity":"Low",
                                     "recommendation":"Do not list sensitive endpoints", "evidence": wf.get("snippet","")})
            else:
                if wf.get("server"):
                    vuln_records.append({"endpoint": ep, "title":"Server header disclosure", "severity":"Low",
                                         "recommendation":"Hide version / patch", "evidence": wf.get("server")})
        quick_vulns = run_basic_web_vuln_tests(base_url)
        for q in quick_vulns:
            vuln_records.append({"endpoint": base_url, "title": q.get("title"), "severity": q.get("severity"),
                                 "recommendation": q.get("recommendation"), "evidence": q.get("evidence")})

    # dedupe
    seen = set(); deduped = []
    for v in vuln_records:
        key = (v.get("title"), v.get("endpoint"))
        if key in seen:
            continue
        seen.add(key); deduped.append(v)

    ai = ai_assess(deduped)
    duration = round(time.time() - start, 2)
    scan_meta = {"scan_id": f"scan_{int(time.time())}", "target": hostname, "engine": engine_used,
                 "started_at": datetime.utcnow().isoformat()+"Z", "duration": duration}

    # Results
    st.subheader("Scan Summary")
    st.markdown(f"- **Scan ID:** {scan_meta['scan_id']}")
    st.markdown(f"- **Target:** {scan_meta['target']} ({ip})")
    st.markdown(f"- **Engine:** {scan_meta['engine']}")
    st.markdown(f"- **Started at:** {scan_meta['started_at']}")
    st.markdown(f"- **Runtime (s):** {scan_meta['duration']}")
    st.markdown(f"- **AI Level:** **{ai['level']}** — Score: {ai['score']}")
    st.markdown(f"- **Recommendation:** {ai['recommendation']}")

    if deduped:
        df = pd.DataFrame([{"endpoint": d.get("endpoint"), "title": d.get("title"),
                            "severity": d.get("severity"), "recommendation": d.get("recommendation"),
                            "evidence": d.get("evidence")} for d in deduped])
        st.subheader("Vulnerabilities found")
        st.dataframe(df)
        csv_buf = generate_csv_buffer(scan_meta, deduped)
        st.download_button("Download report (CSV)", data=csv_buf.getvalue(), file_name=f"{scan_meta['scan_id']}.csv",
                           mime="text/csv", key=f"dl_scan_{scan_meta['scan_id']}")
    else:
        st.success("No vulnerabilities detected by heuristics in this quick scan.")

    # store in-session history
    if "history" not in st.session_state:
        st.session_state["history"] = []
    st.session_state["history"].append({"meta":scan_meta, "vulns":deduped, "ai":ai})

# ----------------------------
# Reports UI
# ----------------------------
def reports_ui():
    top_header_compact()
    st.header("Session Scan History")
    history = st.session_state.get("history", [])
    if not history:
        st.info("No scans in this session. Run a scan first.")
        return
    for idx, rec in enumerate(reversed(history)):
        meta = rec["meta"]; ai = rec["ai"]; vulns = rec["vulns"]
        st.markdown(f"### {meta['scan_id']} — {meta['target']} — {ai['level']} (score {ai['score']})")
        st.write(f"Started: {meta['started_at']} — Duration: {meta['duration']}s — Engine: {meta['engine']}")
        if not vulns:
            st.write("No vulnerabilities recorded.")
        else:
            df = pd.DataFrame([{"endpoint":v["endpoint"], "title":v["title"], "severity":v["severity"], "evidence":v["evidence"]} for v in vulns])
            st.dataframe(df)
            csv_buf = generate_csv_buffer(meta, vulns)
            st.download_button(f"Download CSV ({meta['scan_id']})", data=csv_buf.getvalue(),
                               file_name=f"{meta['scan_id']}.csv", mime="text/csv", key=f"dl_report_{idx}")

# ----------------------------
# Settings UI
# ----------------------------
def settings_panel():
    top_header_compact()
    st.header("Settings / Nmap Path")
    st.write("If nmap is not detected, paste the full `nmap.exe` path below and Save.")
    manual = st.text_input("Manual Nmap path (optional)", value=st.session_state.get("manual_nmap_path",""),
                           placeholder=r"C:\Program Files (x86)\Nmap\nmap.exe", key="manual_nmap_field")
    if st.button("Save Nmap path", key="save_nmap_path_btn"):
        st.session_state["manual_nmap_path"] = manual.strip()
        st.success("Saved. The app will try to use this path next scan.")
        ok, path = nmap_available(manual_path=st.session_state.get("manual_nmap_path"))
        if ok:
            st.success(f"nmap found at: {path}")
            st.session_state["nmap_path"] = path
        else:
            st.warning("nmap not found at that path; check path or add to system PATH.")
    if st.button("Detect nmap now", key="detect_now_btn"):
        ok, path = nmap_available(manual_path=st.session_state.get("manual_nmap_path"))
        if ok:
            st.success(f"nmap is available at: {path}")
            st.session_state["nmap_path"] = path
        else:
            st.error("nmap not available. Add it to PATH or paste full path above.")
    st.write("Current detected nmap path:", st.session_state.get("nmap_path", "Not detected"))
    st.info("If you add nmap to system PATH, restart your terminal/IDE before running Streamlit so the venv process inherits the updated PATH.")

# ----------------------------
# About
# ----------------------------
def about_ui():
    top_header_compact()
    st.header("About / Usage")
    st.markdown("""
    **How it works**
    - App tries to detect `nmap` automatically. If not found it will use a TCP fallback.
    - Use Settings to provide `nmap.exe` path if necessary.
    - Only scan systems you own or have explicit permission to test.
    """)
    st.markdown(f"**Author:** {STUDENT}  \n**Supervisor:** {SUPERVISOR}  \n**Matric:** {MATRIC}")

# ----------------------------
# Main router
# ----------------------------
def main():
    if "page" not in st.session_state:
        st.session_state["page"] = "Landing"
    if "manual_nmap_path" not in st.session_state:
        st.session_state["manual_nmap_path"] = ""
    if "nmap_path" not in st.session_state:
        ok, path = nmap_available(manual_path=st.session_state.get("manual_nmap_path"))
        st.session_state["nmap_path"] = path if ok else None

    # --- Sidebar logic ---
    if st.session_state["page"] != "Landing":
        with st.sidebar:
            st.markdown("## Navigation")
            options = ["Landing", "Scan", "Reports", "Settings", "About"]
            index = options.index(st.session_state["page"]) if st.session_state["page"] in options else 0
            page = st.radio("", options=options, index=index, key="nav_radio")
            st.session_state["page"] = page
            st.markdown("---")
            st.write("Tip: If nmap is installed but not detected, paste full path in Settings and Save.")
    else:
        # Empty placeholder to disable sidebar space
        st.markdown(
            """
            <style>
            [data-testid="stSidebar"] {display: none;}
            </style>
            """,
            unsafe_allow_html=True
        )

    # --- Page routing ---
    if st.session_state["page"] == "Landing":
        landing_page()
    elif st.session_state["page"] == "Scan":
        scan_ui()
    elif st.session_state["page"] == "Reports":
        reports_ui()
    elif st.session_state["page"] == "Settings":
        settings_panel()
    else:
        about_ui()


if __name__ == "__main__":
    main()
